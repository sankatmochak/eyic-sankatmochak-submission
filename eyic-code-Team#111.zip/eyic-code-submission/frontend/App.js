/*
* Project Name: 	Sankatmochak frontend
* Author List: 		Jane Doe, e-Yantra Team
* Filename: 		fibonacci.c
* Functions: 		print_fibonacci_series(int) , main()
* Global Variables:	NONE
* This file is entrance to frontend of SankatMochak app.
*/

import React from 'react';
import WelcomeSec from './app/sections/WelcomeSec';

// Serving WelcomeSec as the entrance.
export default function App() {
  return (
    <WelcomeSec/>
  );
}
