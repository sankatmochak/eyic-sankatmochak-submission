import React, {Component, useState} from 'react';
import { StyleSheet, Text, View, Image, Button, Touchable, TouchableOpacity } from 'react-native';
// import 'welcome.png' from '.../assets/images'as WelcomeImage;

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';


const Welcome = ({navigation}) => {

  const redirectSignup = () => {
    navigation.navigate('SignUp');
  };
  const redirectLogin = () => {
    console.log("Heading to Login page!");
    navigation.navigate('LogIn');
  };

  return (
    <View style={styles.container}>
        <Image
            style={styles.signatureImage}
            source={require('./welcome.png')}
        />   

        <TouchableOpacity onPress={redirectSignup}>
            <View style={styles.signUpbutton}>
                  <Text style={styles.signUpbuttonText}> SIGN UP </Text>
            </View>
        </TouchableOpacity>

        <TouchableOpacity onPress={redirectLogin}>
            <View>
                  <Text style={styles.loginText}> Already Have an Account? LOGIN </Text>
            </View>
        </TouchableOpacity>

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 5,
    backgroundColor: '#fff',
    marginVertical: 5, 
    marginHorizontal: 5, 
    alignItems: 'center',
    justifyContent: 'center', 
  },
  signatureImage: {
    width: 350, 
    height: 350,
  },
  signUpbutton: {
    marginVertical: 60,
    marginHorizontal: 10,
    borderRadius: 20, 
    backgroundColor: '#029bfa',
  }, 
  signUpbuttonText: {
    marginHorizontal: 80,
    color: 'white',
    fontWeight: 'bold', 
    fontSize: 30,
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'justify',
  }, 
  loginText: {
    marginHorizontal: 30,
    color: 'blue',
    fontSize: 15,
    alignItems: 'center',
    textAlign: 'justify',
    justifyContent: 'center', 
  }
});

export default Welcome;
