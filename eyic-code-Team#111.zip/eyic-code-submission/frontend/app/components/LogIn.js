import React, {Component, useState} from 'react';
import { StyleSheet, Text, View, Image, Button, TextInput, Touchable, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';


const LogIn = ({navigation}) => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');

  const inputPhone = (val) => {
      setPhone(val);
  }

  const inputPassword = (val) => {
      setPassword(val);
  }

  const postData = async() => {
      try {
          await fetch('https://webhook.site/16361bae-f7a3-4791-9192-76b9ec6f8431', {
              method: 'post', 
              mode: 'no-cors', 
              headers: {
                  'Accept': 'application/json', 
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                  phone: AsyncStorage.getItem('phone'),
                  password: password
              })
          });
      } catch(e) {
          console.warn(e);
      }
  }


  const login = async() => {
    // data = {phone: phone, password: password};
    console.log("Successfully logged in. Heading to Home page!");
    await AsyncStorage.setItem('phone', phone);

    navigation.navigate('Home');
  };

  const redirectSignUp = () => {
    navigation.navigate('SignUp');
  }

  return (
    <View style={styles.container}>
        <Image
            style={styles.signatureImage}
            source={require('./welcome.png')}
        />   
        <Text style={styles.heading}>Login to Your Account</Text>
        
        <TextInput 
            keyboardType='numeric'
            style={styles.input}
            placeholder='Your Phone Number'
            onChangeText={inputPhone} />
        <TextInput 
            style={styles.input}
            secureTextEntry={true}
            placeholder='Your Password'
            onChangeText={inputPassword} />
        <TouchableOpacity onPress={login}>
            <View style={styles.LogInbutton}>
                  <Text style={styles.LogInbuttonText}> LOGIN </Text>
            </View>
        </TouchableOpacity>

        <TouchableOpacity onPress={redirectSignUp}>
            <View>
                  <Text style={styles.signupText}> New User? SIGNUP </Text>
            </View>
        </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 20,
    backgroundColor: '#fff',
    marginVertical: 20, 
    marginHorizontal: 5, 
    alignItems: 'center',
  },
  signatureImage: {
    width: 100, 
    height: 100,
  },
  LogInbutton: {
    marginTop: 30,
    marginBottom: 50,
    marginHorizontal: 10,
    borderRadius: 30, 
    backgroundColor: '#029bfa',
  }, 
  LogInbuttonText: {
    marginHorizontal: 60,
    color: 'white',
    fontWeight: 'bold', 
    paddingVertical: 5,
    fontSize: 20,
    textAlign: 'justify',
  },
  heading: {
    fontSize: 25,
    fontWeight: 'bold', 
  },
  input: {
    borderWidth: 1, 
    padding: 2,
    marginVertical: 10,
    borderRadius: 10,
    width: 300,
  },
  signupText: {
    marginHorizontal: 30,
    color: 'blue',
    fontSize: 15,
    alignItems: 'center',
    textAlign: 'justify',
    justifyContent: 'center', 
  }
});

export default LogIn;
