import React, {useState} from 'react';
import { StyleSheet, Text, View, Button, TextInput, ScrollView, FlatList, Touchable, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';



export default class Sos extends React.Component {
    constructor(){
        super();
        this.state = {
            ready: false,
            where: {lat:null, lng:null},
            latitude: "",
            longitude: "",
            error: null
        }
    }
    accessGeoLocation = () => {
        let geoOptions = {
            enableHighAccuracy: true,
            timeOut: 20000,
            maximumAge: 60 * 60 * 24
        };
        this.setState({ready:false, error: null });
        navigator.geolocation.getCurrentPosition( this.geoSuccess, 
                                                this.geoFailure,
                                                geoOptions);
    }
    geoSuccess = (position) => {
        this.setState({
            ready:true,
            where: {lat: position.coords.latitude,lng:position.coords.longitude },
            latitude: `${position.coords.latitude}`,
            longitude: `${position.coords.longitude}`
        })
    }
    geoFailure = (err) => {
      console.log(err.message);
        this.setState({error: err.message});

        if( err.message !== "Location request failed due to unsatisfied device settings.") {
            this.accessGeoLocation();
        }
    }

    render() {
        return (
          <View>
              <TouchableOpacity onPress={this.accessGeoLocation}>
                  <View style={styles.button}>
                        <Text style={styles.buttonText}> I NEED HELP! </Text>
                  </View>
                  <View>
                      <Text style={styles.info}>(Police or Immediate Disaster Response Team will be approaching your location when you press above button. So be careful about it. )</Text>
                  </View>
              </TouchableOpacity>
          </View>
        );
    }
    
   
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 40,
    paddingHorizontal: 20,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    marginTop: 200,
    marginHorizontal: 20,
    borderRadius: 8, 
    paddingHorizontal: 10,
    paddingTop: 50,
    paddingBottom: 50,
    backgroundColor: '#b0d1d1',
  }, 
  buttonText: {
    color: 'red',
    fontWeight: 'bold', 
    fontSize: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  info: {
    marginHorizontal: 20,
    marginVertical: 30,
    color: 'black', 
    fontSize: 15, 
    fontStyle: 'italic',
    justifyContent: 'center',
    alignItems: 'center',
  }
});
