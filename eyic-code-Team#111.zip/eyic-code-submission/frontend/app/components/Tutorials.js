import React, {useState, useEffect} from 'react';
import { StyleSheet, Text, View, Button, TextInput, 
         ScrollView, FlatList, Touchable, TouchableOpacity, 
         SafeAreaView, ActivityIndicator } from 'react-native';

import Card from './card';


const Tutorials = ({navigation}) => {
  const [tutorial, setTutorial] = useState([]);
  const [isLoading, setLoading] = useState(true);
  const URL =  "https://disaster-turorial.herokuapp.com/tutorials/"; 
  
  async function fetchData() {
    try {
        let data = await fetch(URL);
        let response = await data.json();
        setTutorial(response);
        console.log(tutorial);
        setLoading(false);
    } catch(err) {
        console.log(err);
    }
  }

  useEffect(() => {
    fetchData();
  }, [])

  const fetchItems = async () => {
    const data = await fetch(URL);
    const set = await data.json();
    console.log(set);
    setItems(set);
  };

  return (
    <SafeAreaView style={styles.container}>
          {isLoading ? <ActivityIndicator/> : <FlatList
                                                  data={tutorial}
                                                  keyExtractor={ () => {Math.floor(Math.random() * 10000);}}

                                                  renderItem = {({ item }) => ( 
                                                      <TouchableOpacity onPress={() => navigation.push('TutorialDetails', item)}>
                                                          <Card>
                                                            <Text style={styles.listbeautify}>
                                                              {item.name}
                                                            </Text>
                                                          </Card>
                                                      </TouchableOpacity>
                                                  )}
                                              />
          }
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 40,
    paddingHorizontal: 20,
    backgroundColor: '#fff',
  },
  header: {
    backgroundColor: 'pink',
    padding: 20,
  },
  body: {
    backgroundColor: 'yellow',
    padding: 20,
  },
  boldText: {
    fontWeight: 'bold',
    fontSize: 15,
  }, 
  buttonContainer: {
    marginTop:20,
  },
  listbeautify: {
    flex: 1,
    marginHorizontal: 20,
    marginVertical: 20,
    padding: 30,
    backgroundColor: '#76a6ef',
    fontSize: 20,
  },
  info: {
    marginHorizontal: 5,
    color: 'black', 
    fontSize: 15, 
    fontStyle: 'italic',
    justifyContent: 'center',
    alignItems: 'center',
  }
});

export default Tutorials;
