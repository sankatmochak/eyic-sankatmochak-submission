import React from 'react';
import { View, StyleSheet, TouchableOpacity, Text, Button, FlatList } from 'react-native';
import { AntDesign } from '@expo/vector-icons';

const AlertDetails = ({navigation}) => {

  const goBackToAlerts = () => {
      navigation.goBack();
  }

  return (
    <View style={styles.container}>
      <Text style={{fontWeight: 'bold', fontSize: 40}}> {navigation.getParam('name')} </Text>
      <Text> {navigation.getParam('dateTime')} </Text>
      <Text> {'\n'} </Text>
      <Text> {navigation.getParam('locations')} </Text>
      <Text> {'\n'} </Text>
      <Button title='Go Back' onPress={goBackToAlerts}/>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default AlertDetails;