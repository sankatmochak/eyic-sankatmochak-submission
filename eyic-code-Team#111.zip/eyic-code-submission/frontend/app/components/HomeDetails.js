import React from 'react';
import { View, StyleSheet, TouchableOpacity, Text, Button, FlatList } from 'react-native';
import { AntDesign } from '@expo/vector-icons';

const HomeDetails = ({navigation}) => {

  const goBackToHome = () => {
      navigation.goBack();
  }

  return (
    <View style={styles.container}>
      <Text style={{fontWeight: 'bold', fontSize: 40}}> {navigation.getParam('name')} </Text>
      <Text> {navigation.getParam('dateTime')} </Text>
      <Text> {'\n'} </Text>
      <Text> {navigation.getParam('detail')} </Text>
      
      <Button title='Go Back' onPress={goBackToHome}/>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,
  },
});

export default HomeDetails;