import React, {useState} from 'react';
import { View, StyleSheet, Text, Button, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Card from './card';


export default class Profile extends React.Component {
  constructor(){
        super();
        this.state = {
            ready: false,
            fullname: "",
            phone: 0,
            age: 0, 
            location: 0
        }
    }

  componentDidMount = async() => {

      this.setState({fullname: await AsyncStorage.getItem('fullname'), 
                      phone: await AsyncStorage.getItem('phone'),
                      age: await AsyncStorage.getItem('age'), 
                      location: await AsyncStorage.getItem('location'), 
                      ready: true});
  }

  logout = async() => {
      await AsyncStorage.clear();
  }
  render() {
    return (
      <View style={styles.container}>
        { ! this.state.ready && (
                  <Text style={styles.text}>loading...</Text>
        )}

        { this.state.ready && (
          <Card>
          <Text style={styles.heading}>My Profile {'\n'}
          <Text style={styles.text}>Full Name: {'\n'}{this.state.fullname} {'\n'}{'\n'}
                                     Phone number:{'\n'}{this.state.phone} {'\n'}{'\n'}
                                     Age: {'\n'}{this.state.age} {'\n'}{'\n'}
                                     Location: {'\n'}{this.state.location} {'\n'} </Text> 
          </Text>
          </Card>
        )}
        <Button
            title="Logout"
            onPress={() => this.logout}
        />
        
      </View>
    );
  }
  
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'justify',
    backgroundColor: '#76a6ef',
  },
  heading: {
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'justify',
    fontSize: 40,
  },
  text: {
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'justify',
    fontSize: 18,
  },
  listbeautify: {
    flex: 1,
    marginHorizontal: 0,
    marginVertical: 0,
    padding: 2,
    backgroundColor: '#76a6ef',
    fontSize: 15,
  },
});