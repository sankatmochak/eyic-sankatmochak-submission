import React, {Component, useState} from 'react';
import { StyleSheet, Text, View, Image, Button, TextInput, Touchable, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

const SignUp = ({navigation}) => {

  const [fullname, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [age, setAge] = useState('');
  const [location, setLocation] = useState('');
  const [role, setRole] = useState('');

  const inputName = (val) => {
      setName(val);
  }
  const inputPhone = (val) => {
      setPhone(val);
  }
  const inputPassword = (val) => {
      setPassword(val);     
  }
  const inputAge = (val) => {
      setAge(val);
  }
  const inputLocation = (val) => {
      setLocation(val);
  }

  const postData = async() => {
      console.log("Your account is being created !");
      try {
          await fetch('https://webhook.site/16361bae-f7a3-4791-9192-76b9ec6f8431', {
              method: 'post', 
              mode: 'no-cors', 
              headers: {
                  'Accept': 'application/json', 
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                  fullname: AsyncStorage.getItem('fullname'), 
                  phone: AsyncStorage.getItem('phone'),
                  password: password,
                  age: AsyncStorage.getItem('age'),
                  location: AsyncStorage.getItem('location'),
              })
          });
      } catch(e) {
          console.warn(e);
      }
  }


  const signup = async() => {
    await setRole('user');
    // data = {fullname: fullname, phone: phone, password: password, age: age, location: location, role: role};

    console.log("Heading to signup page!");
    await AsyncStorage.setItem('fullname', fullname);
    await AsyncStorage.setItem('phone', phone);
    await AsyncStorage.setItem('age', age);
    await AsyncStorage.setItem('location', location);

    await postData();

    await alert('please login with your new account !');
    navigation.push('LogIn');
  };
  const check = async() => {
    setRole('user');
    AsyncStorage.getItem('phone').
    then((value) => {
        const val = value;
        console.log(val);
    })

  };
  const redirectLogin = () => {
    navigation.navigate('LogIn');
  }

  return (
    <View style={styles.container}>
        <Image
            style={styles.signatureImage}
            source={require('./welcome.png')}
        />   
        <Text style={styles.heading}>Create Your Account</Text>
        
        <TextInput 
            style={styles.input}
            placeholder='Your Full Name'
            onChangeText={inputName} />
        <TextInput 
            keyboardType='numeric'
            style={styles.input}
            placeholder='Your Phone Number'
            onChangeText={inputPhone} />
        <TextInput 
            style={styles.input}
            secureTextEntry={true}
            placeholder='Your Password'
            onChangeText={inputPassword} />
        <TextInput 
            keyboardType='numeric'
            style={styles.input}
            placeholder='Your age'
            onChangeText={inputAge} />
        <TextInput 
            keyboardType='numeric'
            style={styles.input}
            placeholder='Your Pin Code'
            onChangeText={inputLocation} />
        <TouchableOpacity onPress={signup}>
            <View style={styles.signUpbutton}>
                  <Text style={styles.signUpbuttonText}> GET STARTED </Text>
            </View>
        </TouchableOpacity>

         <TouchableOpacity onPress={redirectLogin}>
            <View>
                  <Text style={styles.loginText}> Already Have an Account? LOGIN </Text>
            </View>
        </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 5,
    backgroundColor: '#fff',
    marginVertical: 5, 
    marginHorizontal: 5, 
    alignItems: 'center',
  },
  signatureImage: {
    width: 100, 
    height: 100,
  },
  signUpbutton: {
    marginVertical: 40,
    marginHorizontal: 10,
    borderRadius: 30, 
    backgroundColor: '#029bfa',
  }, 
  signUpbuttonText: {
    marginHorizontal: 60,
    color: 'white',
    fontWeight: 'bold', 
    paddingVertical: 5,
    fontSize: 20,
    textAlign: 'justify',
  },
  heading: {
    fontSize: 25,
    fontWeight: 'bold', 
  },
  input: {
    borderWidth: 1, 
    padding: 2,
    marginVertical: 10,
    borderRadius: 10,
    width: 300,
  },
  loginText: {
    marginHorizontal: 30,
    color: 'blue',
    fontSize: 15,
    alignItems: 'center',
    textAlign: 'justify',
    justifyContent: 'center', 
  }
});

export default SignUp;
