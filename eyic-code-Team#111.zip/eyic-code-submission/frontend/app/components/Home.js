import React, {useState} from 'react';
import { StyleSheet, Text, View, TouchableOpacity, FlatList } from 'react-native';
import AnimatedScrollView from './AnimatedScrollView';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Card from './card';

const Home = ({navigation}) => {
  const [newslist, setNewsList] = useState([ 
    { _id: '1', name: 'Tsunami in Banglore', dateTime: '30 March, 2021', detail: "Yesterday evening a Tsunami affected Bangluru and nearby areas in Karnataka. It was caused by strong winds and came from eastern shores. Loss worth 20 billion INR estimated. Thankfully we were able to save all of our precious lives in affected areas." },
    { _id: '2', name: 'Flood in Assam', dateTime: '29 March, 2021', detail: "Day before yesterday evening a Flood affected Bangluru and nearby areas in Karnataka. It was caused by strong winds and came from eastern shores. Loss worth 1 billion INR estimated. Thankfully we were able to save all of our precious lives in affected areas." },
    { _id: '3', name: 'Change in Standards for Construction', dateTime: '28 March, 2021', detail: "IN early morning at 4:00 am Light earthqake of scale 3.0 observed in Delhi. No loss of live or property was caused. Although it seems to be caused by heavy industrial acitivities in the locality. These kind of events are buzzer for us to be aware of what we are doing and how it is affecting natural processes." },
    { _id: '4', name: 'Earthqnake in Delhi', dateTime: '25 March, 2021', detail: "IN early morning at 4:00 am Light earthqake of scale 3.0 observed in Delhi. No loss of live or property was caused. Although it seems to be caused by heavy industrial acitivities in the locality. These kind of events are buzzer for us to be aware of what we are doing and how it is affecting natural processes." },
    { _id: '5', name: 'Earthqnake in Maharashtra', dateTime: '23 March, 2021', detail: "IN early morning at 4:00 am Light earthqake of scale 3.0 observed in Delhi. No loss of live or property was caused. Although it seems to be caused by heavy industrial acitivities in the locality. These kind of events are buzzer for us to be aware of what we are doing and how it is affecting natural processes." },
    { _id: '6', name: 'Earthqnake in Delhi', dateTime: '21 March, 2021', detail: "IN early morning at 4:00 am Light earthqake of scale 3.0 observed in Delhi. No loss of live or property was caused. Although it seems to be caused by heavy industrial acitivities in the locality. These kind of events are buzzer for us to be aware of what we are doing and how it is affecting natural processes." },
    { _id: '7', name: 'Earthqnake in Delhi', dateTime: '20 March, 2021', detail: "IN early morning at 4:00 am Light earthqake of scale 3.0 observed in Delhi. No loss of live or property was caused. Although it seems to be caused by heavy industrial acitivities in the locality. These kind of events are buzzer for us to be aware of what we are doing and how it is affecting natural processes." },
    { _id: '8', name: 'Earthqnake in Delhi', _id: '8', dateTime: '1 March, 2021', detail: "IN early morning at 4:00 am Light earthqake of scale 3.0 observed in Delhi. No loss of live or property was caused. Although it seems to be caused by heavy industrial acitivities in the locality. These kind of events are buzzer for us to be aware of what we are doing and how it is affecting natural processes." }
  ]);

  return (
    <View style={styles.container}>
          <FlatList
            data={newslist}
            keyExtractor = { (item) => item._id }
            renderItem = {({ item }) => (
                <TouchableOpacity onpress={() => navigation.push('HomeDetails', item)}>
                  <Card>
                        <Text> {item.name} </Text>
                  </Card>
                </TouchableOpacity>
            )}
          />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 30,
    marginHorizontal:5,
    backgroundColor: '#76a6ef',
  },
  text: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default Home;