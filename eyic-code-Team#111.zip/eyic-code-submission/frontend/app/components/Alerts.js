import React, {Component, useState} from 'react';
import { StyleSheet, Text, View, Button, TextInput, ScrollView, FlatList, Touchable, TouchableOpacity } from 'react-native';

const Alerts = ({navigation}) => {

    const [alert, setAlert] = useState([
    { name: 'Flood', id: '1', dateTime: '23 April, 2021', locations: "Assam, Meghalaya, West Bengal" },
    { name: 'Flood', id: '2', dateTime: '25 April, 2021', locations: "Meerut, Kanpur, Lucknow" },
    { name: 'Avalanche', id: '3', dateTime: '23 April, 2021', locations: "Meerut, Kanpur, Lucknow" },
    { name: 'Tsunami', id: '4', dateTime: '23 April, 2021', locations: "Meerut, Kanpur, Lucknow" },
    { name: 'Drought', id: '5', dateTime: '23 April, 2021', locations: "Meerut, Kanpur, Lucknow" },
    { name: 'Flood', id: '6', dateTime: '23 April, 2021', locations: "Meerut, Kanpur, Lucknow" },
    { name: 'Earthquake', id: '7', dateTime: '23 April, 2021', locations: "Meerut, Kanpur, Lucknow" },
    { name: 'Nuclear Emenrgency', id: '8', dateTime: '23 April, 2021', locations: "Meerut, Kanpur, Lucknow" },
  ]);

  return (
    <View style={styles.container}>

    <Button title='My Alerts' onPress={gotoMyAlerts}/>

    <FlatList 
        keyExtractor = { (item) => item.id } 
        data = {alert} 
        renderItem = {({ item }) => ( 
          <TouchableOpacity onPress={() => navigation.push('AlertDetails', item)}>
              <Text style={styles.listbeautify}>
                  {item.name}

                  <Text style={styles.dateStyle}>
                        {'\n'}
                  </Text>
                  
                  <Text style={styles.dateStyle}>
                        {item.dateTime}
                  </Text>
                 
                  
              </Text>
          </TouchableOpacity>
        )}
      />
    
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 40,
    paddingHorizontal: 20,
    backgroundColor: '#fff',
  },
  header: {
    backgroundColor: 'pink',
    padding: 20,
  },
  body: {
    backgroundColor: 'yellow',
    padding: 20,
  },
  boldText: {
    fontWeight: 'bold',
    fontSize: 20,
  }, 
  buttonContainer: {
    marginTop:20,
  },
  listbeautify: {
    flex: 1,
    marginHorizontal: 20,
    marginTop: 20,
    padding: 30,
    backgroundColor: '#76a6ef',
    fontSize: 15,
    marginHorizontal: 5,
  },
  dateStyle: {
    fontSize: 12,
    fontStyle: 'italic',
    flex: 1, 
  }
});

export default Alerts;
