import React, {Component, useState} from 'react';
import { StyleSheet, Text, View, Button, TextInput, ScrollView, FlatList, Touchable, TouchableOpacity } from 'react-native';

const MyAlerts = () => {

    const [alert, setAlert] = useState([
        { name: 'Foold', id: '1', dateTime: '2 April, 2021', locations: "Shahanjahanpur, Kanpur, Lucknow" },
        { name: 'Flood', id: '2', dateTime: '3 April, 2021', locations: "Shahanjahanpur, Kanpur, Lucknow" },
    ]);

  return (
    
     <View style={styles.container}>
    <FlatList 
        keyExtractor = { (item) => item.id } 
        data = {alert} 
        renderItem = {({ item }) => ( 
          <TouchableOpacity onPress={() => navigation.push('AlertDetails', item)}>
              <Text style={styles.listbeautify}>
                  {item.name}

                  <Text style={styles.dateStyle}>
                        {'\n'}
                  </Text>
                  
                  <Text style={styles.dateStyle}>
                        {item.dateTime}
                  </Text>
                 
                  
              </Text>
          </TouchableOpacity>
        )}
      />
    
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 40,
    paddingHorizontal: 20,
    backgroundColor: '#fff',
  },
  header: {
    backgroundColor: 'pink',
    padding: 20,
  },
  body: {
    backgroundColor: 'yellow',
    padding: 20,
  },
  boldText: {
    fontWeight: 'bold',
    fontSize: 20,
  }, 
  buttonContainer: {
    marginTop:20,
  },
  listbeautify: {
    flex: 1,
    marginHorizontal: 20,
    marginTop: 20,
    padding: 30,
    backgroundColor: '#76a6ef',
    fontSize: 15,
    marginHorizontal: 5,
  },
  dateStyle: {
    fontSize: 12,
    fontStyle: 'italic',
    flex: 1, 
  }
});

export default MyAlerts;
