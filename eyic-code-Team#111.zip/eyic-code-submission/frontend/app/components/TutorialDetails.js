import React from 'react';
import { View, StyleSheet, TouchableOpacity, Text, Button, SafeAreaView } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import AnimatedScrollView from './AnimatedScrollView';

const TutorialDetails = ({navigation}) => {
  const goBackToTutorials = () => {
      navigation.goBack();
  }
  return (
    <AnimatedScrollView >
      <Text style={{fontWeight: 'bold', fontSize: 40}}> TutorialDetails </Text>
      <Text> do before: 
            {'\n'} {'\n'} 
            Practice Drop, Cover, and Hold On with family and coworkers.
            Make an Emergency Plan: Create a family emergency communications plan that has an out-of-state contact. Plan where to meet if you get separated. Make a supply kit that includes enough food and water for several days, a flashlight, a fire extinguisher and a whistle. Protect Your Home: Secure heavy items in your home like bookcases, refrigerators, televisions and objects that hang on walls. Store heavy and breakable objects on low shelves. Consider making improvements to your building to fix structural issues that could cause your building to collapse during an earthquake. Consider obtaining an earthquake insurance policy. A standard homeowner’s insurance policy() does not cover earthquake damage.
            {'\n'} {'\n'} 
            do during: {'\n'} {'\n'} 
            If you are in a car, pull over and stop. Set your parking brake. If you are in bed, turn face down and cover your head and neck with a pillow. If you are outdoors, stay outdoors away from buildings.                                                             If you are inside, stay and do not run outside and avoid doorways.                                                  follow these steps:                                                                                                 Drop (or Lock):- Wherever you are, drop down to your hands and knees and hold onto something sturdy. If you’re using a wheelchair or walker with a seat, make sure your wheels are locked and remain seated until the shaking stops.Cover:- Cover your head and neck with your arms. If a sturdy table or desk is nearby, crawl underneath it for shelter. If no shelter is nearby, crawl next to an interior wall (away from windows). Crawl only if you can reach better cover without going through an area with more debris. Stay on your knees or bent over to protect vital organs. Hold On:-If you are under a table or desk, hold on with one hand and be ready to move with it if it moves. If seated and unable to drop to the floor, bend forward, cover your head with your arms and hold on to your neck with both hands.
            {'\n'}{'\n'} 
            do after:
            {'\n'}{'\n'} 
            After an earthquake, there can be serious hazards such as damage to the building, leaking gas and water lines, or downed power lines. Wash your hands with soap and water after holding on to commonly touched surfaces or objects. If you are unable to wash your hands, use hand sanitizer that contains at least 60 percent alcohol.  Expect aftershocks to follow the main shock of an earthquake. Be ready to Drop, Cover, and Hold On if you feel an aftershock.  If you are in a damaged building, go outside and quickly move away from the building. Do not enter damaged buildings.                                                                                                          If you are trapped, press SOS beakon and also add landmark identification of your location. Check yourself to see if you are hurt and help others if you have training. Learn how to be the help until help arrives.                                                                                                            Once you are safe, pay attention to local news reports for emergency information and instructions via battery-operated radio, TV, social media or from cell phone text alerts.
        </Text>
      
      <Button title='Go Back' onPress={goBackToTutorials}/>
    </AnimatedScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,
  },
});

export default TutorialDetails;