import React, {Component, useState} from 'react';
import { StyleSheet, Text, View, Button, TextInput, ScrollView, FlatList, Touchable, TouchableOpacity } from 'react-native';

import AlertStack from '../navigation/AlertStack';


const AlertSec = () => {
  return (
      <AlertStack/>
  );
};

export default AlertSec;
