import React, {Component, useState} from 'react';
import { StyleSheet, Text, View, Button, TextInput, ScrollView, FlatList, Touchable, TouchableOpacity } from 'react-native';

import WelcomeNavigator from '../navigation/WelcomeNavigator';
import { NavigationContainer } from '@react-navigation/native';

const TutorialSec = () => {
  return (
      <WelcomeNavigator/>
  );
};

export default TutorialSec;
