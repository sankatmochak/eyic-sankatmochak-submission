import React, {Component, useState} from 'react';
import { StyleSheet, Text, View, Button, TextInput, ScrollView, FlatList, Touchable, TouchableOpacity } from 'react-native';

import TutorialStack from '../navigation/TutorialStack';


const TutorialSec = () => {
  return (
      <TutorialStack/>
  );
};

export default TutorialSec;
