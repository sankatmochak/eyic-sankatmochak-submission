import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';

export default function ApiPost(props){
  
  const postData = async() => {
      console.log("Data will be posted soon!");
      try {
          await fetch('https://webhook.site/16361bae-f7a3-4791-9192-76b9ec6f8431', {
              method: 'post', 
              mode: 'no-cors', 
              headers: {
                  'Accept': 'application/json', 
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                  fullname: props.fullname, 
                  location: props.location,
                  phone: props.phone,
              })
          });
      } catch(e) {
          console.warn(e);
      }
  }


  return (
    <View style={styles.container}>
      <Text> Post data </Text>
      <Button title="press Me" onPress={postData}/>
    </View>
  );
  
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 30,
  },
});
