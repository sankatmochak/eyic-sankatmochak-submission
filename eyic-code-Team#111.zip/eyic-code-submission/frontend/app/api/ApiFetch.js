import { StatusBar } from 'expo-status-bar';
import React, {useState, useEffect} from 'react';
import { StyleSheet, Text, View, SafeAreaView, FlatList, ActivityIndicator } from 'react-native';

export default function ApiFetch(props) {

  const [isLoading, setLoading] = useState(true);
  const [Data, setData] = useState([]);

  const URL =  props.URL; 
  
  async function fetchData() {
      let data = await fetch(URL);
      let response = await data.json();
      setData(response.movies);
      setLoading(false);
  }

  useEffect(() => {
    fetchData();
  }, [])

  const fetchItems = async () => {
    const data = await fetch(
      URL
    );

    const set = await data.json();
    console.log(set);
    setItems(set);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={{fontSize:25}}> API CALL </Text>
          {isLoading ? <ActivityIndicator/> : <FlatList
                                                  data={Data}
                                                          keyExtractor={ (item) => item.id }

                                                  renderItem = {({ item }) => ( 
                                                      <Text>{item.id}: {item.title}, {item.releaseYear} </Text>
                                                  )}
                                              />
      }
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 30,
  },
});
