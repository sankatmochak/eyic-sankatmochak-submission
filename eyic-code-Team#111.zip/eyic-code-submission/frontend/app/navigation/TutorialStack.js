import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';
import Tutorials from '../components/Tutorials';
import TutorialDetails from '../components/TutorialDetails';

const screens = {
  Tutorials: {
    screen: Tutorials,
  },
  TutorialDetails: {
    screen: TutorialDetails,
  },
};

// home stack navigator screens
const TutorialStack = createStackNavigator(screens);

export default createAppContainer(TutorialStack);

