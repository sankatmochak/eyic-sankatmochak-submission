import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import TabBar from '../components/TabBar';

import Sos from '../components/Sos';
import Tutorials from '../components/Tutorials';
import Alerts from '../components/Alerts';

import Home from '../components/Home';
import Profile from '../components/Profile';

import AlertSec from '../sections/AlertSec';
import TutorialSec from '../sections/TutorialSec';

const Tab = createBottomTabNavigator();
const TabNavigator = () => {
  return (
    <Tab.Navigator tabBar={props => <TabBar {...props} />}>
      <Tab.Screen
        name='Home'
        component={Home}
        initialParams={{ icon: 'home' }}
      />
      <Tab.Screen
        name='Tutorials'
        component={TutorialSec}
        initialParams={{ icon: 'check' }}
      />
      <Tab.Screen
        name='SOS'
        component={Sos}
        initialParams={{ icon: 'customerservice' }}
      />
      <Tab.Screen
        name='Alerts'
        component={AlertSec}
        initialParams={{ icon: 'clockcircleo' }}
      />
      <Tab.Screen
        name='Profile'
        component={Profile}
        initialParams={{ icon: 'user' }}
      />
    </Tab.Navigator>
  );
};

export default TabNavigator;
