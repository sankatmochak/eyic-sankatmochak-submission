import React from 'react';
import { NavigationContainer } from '@react-navigation/native';

import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';

import Welcome from '../components/Welcome';
import SignUp from '../components/SignUp';
import LogIn from '../components/LogIn';
import Home from '../components/Home';
import WelcomeSec from '../sections/WelcomeSec';
import Main from '../sections/Main';

const AppStack =() => {
  return (
    <View></View>
    // <NavigationContainer>
    //   // <Stack.Navigator>
    //   //   <Stack.Screen name="WelcomeSec" component={WelcomeSec} />
    //   //   <Stack.Screen name="Main" component={Main} />
    //   // </Stack.Navigator>

    //   <RootStack.Navigator mode="modal">
    //     <RootStack.Screen
    //       name="Welcome"
    //       component={WelcomeSec}
    //       options={{ headerShown: false }}
    //     />
    //     <RootStack.Screen name="Home" component={Main} />
    //   </RootStack.Navigator>

    // </NavigationContainer>
  );
}

export default AppStack;