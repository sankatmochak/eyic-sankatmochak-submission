import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';

import Alerts from '../components/Alerts';
import AlertDetails from '../components/AlertDetails';
import MyAlerts from '../components/MyAlerts';


const screens = {
  Alerts: {
    screen: Alerts,
  },
  AlertDetails: {
    screen: AlertDetails,
  },
  MyAlerts: {
  	screen: MyAlerts,
  },
};

// home stack navigator screens
const AlertStack = createStackNavigator(screens);

export default createAppContainer(AlertStack);