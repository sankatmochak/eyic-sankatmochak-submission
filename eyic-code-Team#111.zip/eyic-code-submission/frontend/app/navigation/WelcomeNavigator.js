import React from 'react';
import { NavigationContainer } from '@react-navigation/native';

import { createStackNavigator } from '@react-navigation/stack';
import { createAppContainer } from 'react-navigation';

// import { NavigationContainer } from '@react-navigation/native';
// import { createStackNavigator } from '@react-navigation-stack';


import Welcome from '../components/Welcome';
import SignUp from '../components/SignUp';
import LogIn from '../components/LogIn';
import Home from '../components/Home';

import Main from '../sections/Main';

// const screens = {
//   Welcome: {
//     screen: Welcome,
//     options: { headerShown: false }
//   },
//   SignUp: {
//     screen: SignUp,
//     options: { headerShown: false }
//   },
//   LogIn: {
//   	screen: LogIn,
//     options: { headerShown: false }
//   },
//   Home: {
//   	screen: Home,
//     options: { headerShown: false }
//   },
// };

// const WelcomeStack = createStackNavigator(screens);

// export default createAppContainer(WelcomeStack);



export default function WelcomeStack() {
  const Stack = createStackNavigator();
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{headerShown: false}}>
        <Stack.Screen name="Welcome" component={Welcome} />
        <Stack.Screen name="SignUp" component={SignUp} />
        <Stack.Screen name="LogIn" component={LogIn} />
        <Stack.Screen name="Home" component={Main} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}