import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';
import Home from '../components/Home';
import HomeDetails from '../components/HomeDetails';

const screens = {
  Home: {
    screen: Home,
  },
  HomeDetails: {
    screen: HomeDetails,
  },
};

// home stack navigator screens
const HomeStack = createStackNavigator(screens);

export default createAppContainer(HomeStack);