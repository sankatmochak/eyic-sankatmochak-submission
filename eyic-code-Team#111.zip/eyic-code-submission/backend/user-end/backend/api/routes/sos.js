const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Sos = require('../models/sos');


/**********************************   		 Post SoS request		**************************************/

router.post('/', async(req, res) => {
	const phone = req.body.phone;
	const age = req.body.age;
	const latitude = req.body.latitude;
	const longitude = req.body.longitude;
	const fullname = req.body.fullname;

	const sos = new Sos({
		_id: new mongoose.Types.ObjectId(), 
		phone: phone,			 
		latitude: latitude,
		longitude: longitude,
		fullname: fullname
	});

	try{
		const sosData = await sos.save();
		res.json(sosData);
	}catch(err) {
		res.send("Error:" + err);
	}
});


/***********************************  		 Get SoS request		*************************************/

router.get('/', async(req, res) => {
	// res.send("get Request of warnings.");

	try{
		const sos = await Sos.find();
		res.json(sos);
	}catch(err){
		res.send('Error: ' + err);
	}
});

module.exports = router;