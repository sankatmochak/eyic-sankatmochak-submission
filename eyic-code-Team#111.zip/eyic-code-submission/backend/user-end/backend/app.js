/*
* Project Name: 	SankatMochak app
* Author List: 		Khushi Agarwal, Aditya Shaurya, Anant Agarwal, Kaustub Jaiswal
* Filename: 		app.js
* Functions: 		cooneting database, calling different methods on routes via different files
* Global Variables:	app, URL, dbURI, routes
* This file is the entrance to user-side backend of SankatMochak.
*/




const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const connect = require('connect');
const serveStatic = require('serve-static'); 
const uriUtil = require('mongodb-uri');

const app = express();


/********************************              Create a new DB connection         ************************/
const URL = process.env.MongoDB_URL;
mongoose.Promise = global.Promise
// mongoose.set('debug', DEBUG)

const dbURI = uriUtil.formatMongoose(process.env.MongoDB_URL)

mongoose.connect(dbURI, {useNewUrlParser: true, useUnifiedTopology: true})
		.then(() => app.listen(3000, () => console.log("server started!")))
		.catch((error) => console.log(error.message));

mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);


/**********************************                MIDDLEWARES             ***************************/

// Send and Recieve JSON data
app.use(express.json({extended: true}));


// Allow all requests from all domains & localhost
app.use(cors());
app.all('/*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With, Content-Type, Accept");
  res.header("Access-Control-Allow-Methods", "POST, GET");
  next();
});


/******************************         ROUTES            **********************************/


/*******************************         USER rOUTES        ********************************/

const tutorialRoutes = require('./api/routes/tutorials');
const warningRoutes = require('./api/routes/warnings');
const sosRoutes = require('./api/routes/sos');
const userFunctionRoutes = require('./api/routes/users');
const displayRoutes = require('./api/routes/display');

app.use('/tutorials', tutorialRoutes);
app.use('/warnings', warningRoutes);
app.use('/sos', sosRoutes);
app.use('/user', userFunctionRoutes);