const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Tutorial = require('../models/tutorial');;


/**********************************   		 Get all tutorials		**************************************/

router.get('/', async(req, res) => {
	// res.send("get Request of tutorials.");

	try{
		const tutorials = await Tutorial.find();
		res.json(tutorials);
	}catch(err){
		res.send('Error: ' + err);
	}
});


/**********************************   		 Get a particular tutorial		**************************************/

router.get('/:id', async(req, res) =>{
	try{
		const tutorial = await Tutorial.findById(req.params.id);
		res.json(tutorial);
	}catch(err){
		res.send('Error: ' + err);
	}
});


/**********************************   		 Post a tutorial		**************************************/

router.post('/', async(req, res) => {
	const tutorial = new Tutorial({
		_id: new mongoose.Types.ObjectId(), 
		name: req.body.name,
		intro: req.body.intro, 
		do_before: req.body.do_before,
		do_during: req.body.do_during,
		do_after: req.body.do_after,
	})
	try{
		const tutorialData = await tutorial.save();
		res.json(tutorialData);
	}catch(err) {
		res.send("Error:" + err);
	}
});


/*******************************   		 Patch a particular tutorial		******************************/

router.patch('/:id', async(req, res) =>{
	try{
		const tutorial = await Tutorial.findById(req.params.id);
		tutorial.name = req.body.name;
		tutorial.intro = req.body.intro;
		tutorial.do_before = req.body.do_before;
		tutorial.do_during = req.body.do_during;
		tutorial.do_after = req.body.do_after;
		const tutorialData = await tutorial.save();
		res.status(204).json(tutorialData);
	}catch(err){
		res.send('Error: ' + err);
	}
});


/*****************************   		 Delete a particular tutorial		******************************/

router.delete('/:id', async(req, res) =>{
	try{
		const tutorial = await Tutorial.findById(req.params.id);
		tutorial.remove();
		res.json(tutorial);
	}catch(err){
		res.send('Error: ' + err);
	}
});

module.exports = router