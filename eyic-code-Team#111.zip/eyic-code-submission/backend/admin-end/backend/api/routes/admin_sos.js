const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Sos = require('../models/sos');

/**********************************   		 Get all SoS requests		**************************************/

router.get('/', async(req, res) => {
	// res.send("get Request of sos.");

	try{
		const sos = await Sos.find();
		res.json(sos);
	}catch(err){
		res.send('Error: ' + err);
	}
});

/**********************************   		 Get a particular SoS		**************************************/

router.get('/:id', async(req, res) =>{
	try{
		const sos = await Sos.findById(req.params.id);
		res.json(sos);
	}catch(err){
		res.send('Error: ' + err);
	}
});


/*****************************  	Add if relief was reached, and in time	  *****************************/

router.patch('/:id', async(req, res) =>{
	try{
		const sos = await Sos.findById(req.params.id);
		sos.help_reached = req.body.help_reached;
		sos.help_reached_in_time = req.body.help_reached_in_time;
		const sosData = await sos.save();
		res.status(204).json(sosData);
	}catch(err){
		res.send('Error: ' + err);
	}
});


/**********************************   		 Delete SoS request		**************************************/

router.delete('/:id', async(req, res) =>{
	try{
		const sos = await Sos.findById(req.params.id);
		sos.remove();
		res.json(sos);
	}catch(err){
		res.send('Error: ' + err);
	}
});

module.exports = router