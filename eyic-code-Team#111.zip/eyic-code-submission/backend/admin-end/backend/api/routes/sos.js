const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Sos = require('../models/sos');


/**********************************   		 Post SoS request		**************************************/

router.post('/', async(req, res) => {
	// const {token, where} = req.body;		// GET JWT_TOKEN of as we want all the functionality in single button press
	const phone = req.body.phone;
	const age = req.body.age;
	const latitude = req.body.latitude;
	const longitude = req.body.longitude;
	const fullname = req.body.fullname;
	// const token = req.body.token;

	// userData = atob(token);

	const sos = new Sos({
		_id: new mongoose.Types.ObjectId(), 
		phone: phone,			 
		latitude: latitude,
		longitude: longitude,
		fullname: fullname
	});

	try{
		const sosData = await sos.save();
		res.json(sosData);
	}catch(err) {
		res.send("Error:" + err);
	}
});

module.exports = router;