const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Warning = require('../models/warning');;


/**********************************   		 Get all warnings		**************************************/

router.get('/', async(req, res) => {
	// res.send("get Request of warnings.");

	try{
		const warnings = await Warning.find();
		res.json(warnings);
	}catch(err){
		res.send('Error: ' + err);
	}
});

/******************************   		 Get a particular warning		**********************************/

router.get('/:id', async(req, res) =>{
	try{
		const warning = await Warning.findById(req.params.id);
		res.json(warning);
	}catch(err){
		res.send('Error: ' + err);
	}
});


/**********************************   		 Post a warning			**************************************/

router.post('/', async(req, res) => {
	const warning = new Warning({
		_id: new mongoose.Types.ObjectId(), 
		name: req.body.name,
		dateTime: req.body.dateTime, 
		locations: req.body.locations
	})
	try{
		const warningData = await warning.save();
		res.json(warningData);
	}catch(err) {
		res.send("Error:" + err);
	}
});

/*******************************   		 Post a particular warning		******************************/

router.patch('/:id', async(req, res) =>{
	try{
		const warning = await Warning.findById(req.params.id);
		warning.name = req.body.name;
		warning.dateTime = req.body.dateTime;
		warning.locations = req.body.locations;
		const warningData = await warning.save();
		res.status(204).json(warningData);
	}catch(err){
		res.send('Error: ' + err);
	}
});

	
/*******************************   		Delete a particular warning			******************************/

router.delete('/:id', async(req, res) =>{
	try{
		const warning = await Warning.findById(req.params.id);
		warning.remove();
		res.json(warning);
	}catch(err){
		res.send('Error: ' + err);
	}
});

module.exports = router