const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('../models/user');
const jwt = require('jsonwebtoken');


const JWT_SECRET = process.env.JWT_TOKEN;


/*******************************           SIGN-UP          *********************************/

router.post('/signup', async(req, res) => {
	console.log(req.body);
	const { fullname, phone, password, age, location } = req.body;

	// check if all the fields are filled by the user and have correct datatype
	if(!fullname || typeof fullname !== String || 
		!phone || typeof phone !== Number || 
		!password || typeof password !== String || 
		!age || typeof age !== Number || 
		!location || typeof location !== Number){
		return res.json({status: 'error', message: "all the fields must be filled!"});
	}

	const encryptedPassword = await bcrypt.hash(password, 10);

	const newUser = new User({
		_id: new mongoose.Types.ObjectId(), 
		fullname: req.body.fullname,
		phone: req.body.phone,
		password: encryptedPassword,
		age: req.body.age,
		location: req.body.age
	});
	
	try {
		const userData = await newUser.save();
		res.json(userData);

	} catch(error) {
		console.log(JSON.stringify(error));

		if(error.code === 11000){
			// Duplicate Key
			return res.json({status:"error", error: "phone number already exists. Please login!"});
		}
		throw error;
		 // res.json({status: "error", message: "User could not be created! Please try again."});
	}
	res.json({status: 'ok'});
})

router.get('/', async(req, res) => {
	
	try{
		const users = await User.find();
		res.json(users);
	}catch(err){
		res.send('Error: ' + err);
	}
})


/*********************************            LOGIN            *******************************/

router.post('/login', async (req, res) => {
	const {phone, password} = req.body;

	const findUser = new User({
		phone: req.body.phone,
	});

	const user = await User.findOne( findUser ).lean();

	if(!user) {
		return res.json({status: "error", error: "Invalid Phone number or Password"});
	}
	if(await bcrypt.compare(password, user.password)) {
		// USERNAME - PASSWORD COMBINATION  *SUCCESSFUL*

		const token = jwt.sign({ 
								id: user._id, 
								phone: user.phone
							}, 
							JWT_SECRET );	

		return res.json({status:"ok", data: token})
	} else {
		res.json({status: 'error', error: 'Invalid Phone number or Password'});
	}
})


/*********************************            LIST ALL THE USERS            *******************************/

router.get('/list', async (req, res) => {
	try{
		const users = await User.find();
		res.json(users);
	}catch(err){
		res.send('Error: ' + err);
	}
})



module.exports = router;