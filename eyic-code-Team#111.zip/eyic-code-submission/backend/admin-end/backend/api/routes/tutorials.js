const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Tutorial = require('../models/tutorial');;


/**********************************   		 Get tutorials		**************************************/

router.get('/', async(req, res) => {
	// res.send("get Request of tutorials.");

	try{
		const tutorials = await Tutorial.find();
		res.json(tutorials);
	}catch(err){
		res.send('Error: ' + err);
	}
});

/********************************* 		 Get a particular tutorial		**********************************/

router.get('/:id', async(req, res) =>{
	try{
		const tutorial = await Tutorial.findById(req.params.id);
		res.json(tutorial);
	}catch(err){
		res.send('Error: ' + err);
	}
});

module.exports = router