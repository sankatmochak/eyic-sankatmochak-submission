const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Warning = require('../models/warning');;


/**********************************   		 Get all warnings		**************************************/

router.get('/', async(req, res) => {
	// res.send("get Request of warnings.");

	try{
		const warnings = await Warning.find();
		res.json(warnings);
	}catch(err){
		res.send('Error: ' + err);
	}
});

/**********************************   	 Get a particular warning		**********************************/

router.get('/:id', async(req, res) =>{
	try {
		const warning = await Warning.findById(req.params.id);
		res.json(warning);
	}catch(err) {
		res.send('Error: ' + err);
	}
});


module.exports = router