const mongoose = require('mongoose');

const sosSchema = mongoose.Schema({
	_id: mongoose.Schema.Types.ObjectId, 
	fullname: {
			type:String, 			// name of the user who has posted sos request
			require: false,
			default: ""
		  }, 
	phone: {
		type: Number, 
		required: true
	},
	latitude: {
			type:String, 			// geographic co-ordinates
			require: true
		  },
	longitude: {
			type:String, 			// geographic co-ordinates
			require: true
		  }, 
	help_reached: {
			type:Boolean, 
			defalut: false
		  },
	help_reached_in_time: {
			type:Boolean, 
			defalut: false
		  }	  
});

module.exports = mongoose.model('Sos', sosSchema);