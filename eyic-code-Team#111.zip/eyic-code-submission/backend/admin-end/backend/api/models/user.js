const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
	_id: mongoose.Schema.Types.ObjectId, 
	fullname: {
			type:String, 
			require: true
		  }, 
	phone: {
			type:Number, 
			unique: true,
			require: true
		  }, 
	password: {
			type:String, 
			require: true
		  },
	age: {
			type:Number, 
			require: true
		  },
	location: {
			type:Number, 
			require: true
		  },
	role: {
		type: String,
		default: "user"
	}
});

module.exports = mongoose.model('User', userSchema);