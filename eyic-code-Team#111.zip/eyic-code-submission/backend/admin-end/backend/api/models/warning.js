const mongoose = require('mongoose');

const warningSchema = mongoose.Schema({
	_id: mongoose.Schema.Types.ObjectId, 
	name: {
			type:String, 
			require: true
		  }, 
	dateTime: {
			type:String, 
			require: true
		  }, 
	locations: {
        type: [String], default: []
    }
});

module.exports = mongoose.model('Warning', warningSchema);



