const mongoose = require('mongoose');

const tutorialSchema = mongoose.Schema({
	_id: mongoose.Schema.Types.ObjectId, 
	name: {
			type:String, 
			require: true
		  }, 
	intro: {
			type:String, 
			require: true
		  }, 
	do_before: {
			type:String, 
			require: true
		},
	do_during: {
		type:String, 
		require: true
		},
	do_after: {
			type:String, 
			require: true
		},

});

module.exports = mongoose.model('Tutorial', tutorialSchema);